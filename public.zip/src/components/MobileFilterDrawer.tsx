const MobileFilterDrawer = () => {
  return (
    <div className=''>MobileFilterDrawer</div>
  )
}

export default MobileFilterDrawer