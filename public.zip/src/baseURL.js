// Local url
// export const baseURL = "http://localhost:8000/api/"
// export const baseURLAc = "http://localhost:8000/api/account/"

// Prodaction url
export const baseURL = "http://95.111.229.9:8000/api/"
export const baseURLAc = "https://95.111.229.9:8000/api/account/"
